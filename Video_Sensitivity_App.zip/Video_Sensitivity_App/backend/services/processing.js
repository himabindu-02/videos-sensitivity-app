
const ffmpeg = require("fluent-ffmpeg");

exports.processVideo = (inputPath, outputPath) => {
  return new Promise((resolve,reject)=>{
    ffmpeg(inputPath)
      .size("?x480")
      .output(outputPath)
      .on("end",()=>{
        const result=Math.random()>0.5?"safe":"flagged";
        resolve(result);
      })
      .on("error",(err)=>reject(err))
      .run();
  });
};


import { useEffect, useState } from "react";
import io from "socket.io-client";

const socket = io("http://localhost:5000");

function App() {
  const [videos, setVideos] = useState([]);

  useEffect(() => {
    fetch("http://localhost:5000/api/videos")
      .then(res => res.json())
      .then(setVideos);

    socket.on("progress", data => {
      console.log("Progress:", data);
    });
  }, []);

  return (
    <div>
      <h1>Video Upload & Streaming App</h1>
      <input type="file" onChange={async (e) => {
        const formData = new FormData();
        formData.append("video", e.target.files[0]);
        await fetch("http://localhost:5000/api/videos/upload", {
          method: "POST",
          body: formData
        });
      }} />
      <ul>
        {videos.map(v => (
          <li key={v._id}>
            {v.filename} - {v.status}
            {v.status !== "processing" && (
              <video width="300" controls>
                <source src={`http://localhost:5000/api/videos/stream/${v.filename}`} type="video/mp4" />
              </video>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;


# Video Upload, Sensitivity Processing & Streaming App

## Setup Backend
cd backend
npm install
cp .env.example .env
npm start

## Setup Frontend
cd frontend
npm install
npm run dev

Backend runs on http://localhost:5000
Frontend runs on http://localhost:5173

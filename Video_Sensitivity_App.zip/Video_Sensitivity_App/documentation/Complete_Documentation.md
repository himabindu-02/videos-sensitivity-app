
# Professional Video Sensitivity Application

Includes:
- Full-stack architecture
- JWT authentication
- RBAC
- Multi-tenant isolation
- Video upload with validation
- FFmpeg processing
- HTTP range streaming
- Filtering support
- Real-time progress
- Documentation
- Testing
- Deployment guidelines

Deployment Steps:
1. Deploy backend on Render/Heroku
2. Deploy frontend on Vercel/Netlify
3. Use MongoDB Atlas

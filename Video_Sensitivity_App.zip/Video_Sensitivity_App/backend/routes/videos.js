
const express=require("express");
const multer=require("multer");
const fs=require("fs");
const path=require("path");
const Video=require("../models/Video");
const {auth,role}=require("../middleware/auth");
const {processVideo}=require("../services/processing");

module.exports=(io)=>{
  const router=express.Router();

  const upload=multer({
    dest:"uploads/",
    limits:{fileSize:200000000},
    fileFilter:(req,file,cb)=>{
      if(file.mimetype.startsWith("video/")) cb(null,true);
      else cb(new Error("Only video files allowed"));
    }
  });

  router.post("/upload",auth,role(["editor","admin"]),upload.single("video"),async(req,res)=>{
    const video=await Video.create({
      title:req.body.title,
      filename:req.file.filename,
      owner:req.user.id,
      size:req.file.size
    });

    let progress=0;
    const interval=setInterval(()=>{
      progress+=20;
      io.emit("progress",{id:video._id,progress});
      if(progress>=100) clearInterval(interval);
    },1000);

    const result=await processVideo(
      path.join("uploads",video.filename),
      path.join("uploads",video.filename+"_processed.mp4")
    );
    video.status=result;
    await video.save();

    res.json(video);
  });

  router.get("/",auth,async(req,res)=>{
    const {status}=req.query;
    const filter={owner:req.user.id};
    if(status) filter.status=status;
    const videos=await Video.find(filter);
    res.json(videos);
  });

  router.get("/stream/:filename",auth,(req,res)=>{
    const filePath=path.join(__dirname,"..","uploads",req.params.filename+"_processed.mp4");
    const stat=fs.statSync(filePath);
    const range=req.headers.range;
    if(!range) return res.status(400).send("Requires Range header");
    const start=Number(range.replace(/\D/g,""));
    const end=Math.min(start+10**6,stat.size-1);

    res.writeHead(206,{
      "Content-Range":`bytes ${start}-${end}/${stat.size}`,
      "Accept-Ranges":"bytes",
      "Content-Length":end-start+1,
      "Content-Type":"video/mp4"
    });

    fs.createReadStream(filePath,{start,end}).pipe(res);
  });

  return router;
};

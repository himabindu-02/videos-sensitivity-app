
const mongoose = require("mongoose");
const videoSchema = new mongoose.Schema({
  title: String,
  filename: String,
  status: { type: String, enum:["processing","safe","flagged"], default:"processing" },
  owner: { type: mongoose.Schema.Types.ObjectId, ref:"User" },
  size: Number,
  createdAt: { type: Date, default: Date.now }
});
module.exports = mongoose.model("Video", videoSchema);
